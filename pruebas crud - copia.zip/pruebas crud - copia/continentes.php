<?php
// Conexion a la base de datos
$host = 'localhost';
$user = 'root';
$pass = ''; // Cambia con tu contraseña
$dbname = 'zoologico';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
    exit();
}

// Obtener todos los continentes
$continentesQuery = $pdo->query("SELECT * FROM continentes");
$continentes = $continentesQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las órdenes
$ordenesQuery = $pdo->query("SELECT * FROM orden");
$ordenes = $ordenesQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las familias
$familiasQuery = $pdo->query("SELECT * FROM familia");
$familias = $familiasQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las especies
$especiesQuery = $pdo->query("SELECT * FROM especies");
$especies = $especiesQuery->fetchAll(PDO::FETCH_ASSOC);

// Agregar un animal
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_animal'])) {
    $nombre = $_POST['animal_nombre'];
    $nombre_cientifico = $_POST['nombre_cientifico'];
    $longevidad = $_POST['longevidad'];
    $crias = $_POST['crias'];
    $dato_importante = $_POST['dato_importante'];
    $orden_id = $_POST['orden_id'];
    $familia_id = $_POST['familia_id'];
    $especie_id = $_POST['especie_id'];
    $continente_id = $_POST['continente_id'];

    // Manejo de la imagen
    $imagen = $_FILES['imagen'];
    $imagen_nombre = $imagen['name'];
    $imagen_tmp = $imagen['tmp_name'];
    $uploads_dir = 'uploads/';

    // Verificar si la carpeta 'uploads' existe, si no, crearla
    if (!is_dir($uploads_dir)) {
        mkdir($uploads_dir, 0755, true); // Crea la carpeta con permisos 0755
    }

    $imagen_destino = $uploads_dir . basename($imagen_nombre); // Asegúrate de que la carpeta 'uploads' exista y tenga permisos de escritura

    // Verificar si la imagen se subió correctamente
    if (move_uploaded_file($imagen_tmp, $imagen_destino)) {
        $sql = "INSERT INTO animales (nombre, nombre_cientifico, longevidad, crias, dato_importante, orden_id, familia_id, especie_id, continente_id, imagen) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$nombre, $nombre_cientifico, $longevidad, $crias, $dato_importante, $orden_id, $familia_id, $especie_id, $continente_id, $imagen_destino]);

        // Redirigir para evitar que el formulario se envíe varias veces y agregar un mensaje de éxito
        header("Location: " . $_SERVER['PHP_SELF'] . "?continente_id=" . $continente_id . "&success=1");
        exit();
    } else {
        echo "Error al subir la imagen.";
    }
}

// Editar un animal
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_animal'])) {
    $animal_id = $_POST['animal_id'];
    $nombre = $_POST['animal_nombre'];
    $nombre_cientifico = $_POST['nombre_cientifico'];
    $longevidad = $_POST['longevidad'];
    $crias = $_POST['crias'];
    $dato_importante = $_POST['dato_importante'];
    $orden_id = $_POST['orden_id'];
    $familia_id = $_POST['familia_id'];
    $especie_id = $_POST['especie_id'];

    $sql = "UPDATE animales SET nombre = ?, nombre_cientifico = ?, longevidad = ?, crias = ?, dato_importante = ?, orden_id = ?, familia_id = ?, especie_id = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nombre, $nombre_cientifico, $longevidad, $crias, $dato_importante, $orden_id, $familia_id, $especie_id, $animal_id]);

    // Redirigir para evitar que el formulario se envíe varias veces y agregar un mensaje de éxito
    header("Location: " . $_SERVER['PHP_SELF'] . "?edited=1");
    exit();
}

// Eliminar un animal
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_animal'])) {
    $animal_id = $_POST['animal_id'];

    $sql = "DELETE FROM animales WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$animal_id]);

    // Redirigir para evitar que el formulario se envíe varias veces y agregar un mensaje de éxito
    header("Location: " . $_SERVER['PHP_SELF'] . "?deleted=1");
    exit();
}

// Obtener el continente_id de la URL si está presente
$continente_id_seleccionado = isset($_GET['continente_id']) ? $_GET['continente_id'] : null;

// Obtener animales según el continente seleccionado
$animalesQuery = $pdo->prepare("
    SELECT a.*, o.nombre AS orden_nombre, f.nombre AS familia_nombre, e.nombre AS especie_nombre 
    FROM animales a
    JOIN orden o ON a.orden_id = o.id
    JOIN familia f ON a.familia_id = f.id
    JOIN especies e ON a.especie_id = e.id
    WHERE a.continente_id = ?
");
$animalesQuery->execute([$continente_id_seleccionado]);
$animales = $animalesQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Continentes y Animales</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* El estilo sigue igual */
        .form-container {
            display: none;
            position: fixed; /* Cambiado a fixed para que se mantenga en la pantalla */
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 50%; /* Cambiado a 50% del ancho de la pantalla */
            max-width: 600px; /* Ancho máximo para pantallas grandes */
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow-y: auto; /* Permitir desplazamiento vertical */
            max-height: 80%; /* Altura máxima para evitar que ocupe toda la pantalla */
        }

        .form-container input, .form-container select, .form-container textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .form-container button {
            padding: 10px 20px;
            background-color: #065f46;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #05503a;
        }

        .animal-actions button {
            padding: 5px 10px;
            background-color: #065f46;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 5px; /* Espacio entre botones */
        }

        .animal-actions button:hover {
            background-color: #05503a;
        }

        /* Estilo botón agregar */
        .add-animal-button {
            padding: 12px 25px;
            background-color: #065f46;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 20px;
        }

        .add-animal-button:hover {
            background-color: #05503a;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f2e8;
            color: #333;
            line-height: 1.6;
        }

        main {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            color: #065f46;
            margin-bottom: 2rem;
        }

        .continente-buttons {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .continente-button {
            padding: 15px 30px; /* Aumentar tamaño de botones */
            background-color: #065f46;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 0 10px;
            transition: background-color 0.3s ease; /* Efecto interactivo */
        }

        .continente-button:hover {
            background-color: #05503a;
        }

        .animal-card {
            display: inline-block; /* Cambiado a inline-block para permitir alineación a la derecha */
            border: 1px solid #ddd;
            border-radius: 10px;
            margin: 10px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: calc(33.33% - 20px); /* 3 cartas por fila */
            transition: transform 0.2s; /* Efecto de transición */
            vertical-align: top; /* Alinear la parte superior de las cartas */
        }

        .animal-card:hover {
            transform: scale(1.05); /* Aumentar el tamaño al pasar el mouse */
        }

        .animal-card img {
            width: 100%; /* Ajusta la imagen al ancho de la carta */
            height: auto;
            max-height: 150px; /* Limitar la altura de la imagen */
            object-fit: cover; /* Mantener la proporción de la imagen */
        }

        .animal-card-content {
            padding: 15px;
        }

        .animal-card h3 {
            color: #065f46;
            margin-bottom: 10px;
        }

        .animal-actions {
            margin-top: 10px;
            display: flex;
            justify-content: space-between; /* Alinear botones a los lados */
            align-items: center; /* Centrar verticalmente */
        }

        /* Estilo para la información en negritas */
        .animal-card-content p strong {
            font-family: 'Arial', sans-serif; /* Cambiar tipo de letra */
            font-weight: bold; /* Mantener negrita */
        }

        /* Estilo para la información agregada */
        .animal-card-content p span {
            font-family: 'Courier New', monospace; /* Cambiar tipo de letra */
            font-weight: normal; /* Normalizar peso de la fuente */
        }

        /* Navbar */
        .navbar {
            background-color: #065f46;
            color: white;
            padding: 1rem 2rem;
        }

        .navbar ul {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0;
            margin: 0;
        }

        .navbar li {
            margin: 0 15px;
            list-style: none;
        }

        .navbar a {
            color: white;
            padding: 10px 15px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #05503a;
            border-radius: 5px;
        }

        /* Clearfix para el contenedor de cartas */
        .clearfix {
            display: flex;
            flex-wrap: wrap; /* Permitir que las cartas se envuelvan en filas */
            justify-content: flex-start; /* Alinear las cartas a la izquierda */
        }
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <nav class="navbar w-full p-4 shadow-md">
        <ul class="flex justify-center space-x-8">
            <li><a href="continentes.html" class="px-4 py-2 rounded">Continentes</a></li>
            <li><a href="historia.html" class="px-4 py-2 rounded">Historia</a></li>
            <li><a href="eventos1.html" class="px-4 py-2 rounded">Eventos</a></li>
            <li><a href="zonas.html" class="px-4 py-2 rounded">Zonas</a></li>
            <li><a href="inicioadmin.html" class="px-4 py-2 rounded">Inicio</a></li>
            <li><a href="ajustes.html" class="px-4 py-2 rounded">Ajustes</a></li>
            <li><a href="Index.html" class="px-4 py-2 bg-red-500 rounded hover:bg-red-600">Cerrar Sesión</a></li>
        </ul>
    </nav>

    <main>
        <h2>Continentes y sus Animales</h2>
        
        <!-- Botones de continentes -->
        <div class="continente-buttons">
            <?php foreach ($continentes as $continente): ?>
                <button class="continente-button" onclick="showAnimals('<?php echo $continente['id']; ?>', '<?php echo $continente['nombre']; ?>')">
                    <?php echo $continente['nombre']; ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Título dinámico -->
        <h3 id="dynamic-title" style="text-align: center; color: #065f46; margin-bottom: 20px;">
            <?php echo $continente_id_seleccionado ? 'Animales de ' . $continentes[array_search($continente_id_seleccionado, array_column($continentes, 'id'))]['nombre'] : ''; ?>
        </h3>

        <!-- Fichas de animales -->
        <div id="animal-cards" class="clearfix">
            <?php foreach ($animales as $animal): ?>
                <div class="animal-card">
                    <div class="animal-card-content">
                        <img src="<?php echo $animal['imagen']; ?>" alt="<?php echo $animal['nombre']; ?>">
                        <p><strong>Nombre:</strong> <span id="animal_name_<?php echo $animal['id']; ?>"><?php echo $animal['nombre']; ?></span></p>
                        <p><strong>Nombre Científico:</strong> <span><?php echo $animal['nombre_cientifico']; ?></span></p>
                        <p><strong>Longevidad:</strong> <span><?php echo $animal['longevidad']; ?></span></p>
                        <p><strong>Crias:</strong> <span><?php echo $animal['crias']; ?></span></p>
                        <p><strong>Dato Importante:</strong> <span><?php echo $animal['dato_importante']; ?></span></p>
                        <p><strong>Orden:</strong> <span><?php echo $animal['orden_nombre']; ?></span></p>
                        <p><strong>Familia:</strong> <span><?php echo $animal['familia_nombre']; ?></span></p>
                        <p><strong>Especie:</strong> <span><?php echo $animal['especie_nombre']; ?></span></p>
                        <div class="animal-actions">
                            <div class="action-label">Acciones:</div>
                            <div>
                                <button onclick="showForm(<?php echo htmlspecialchars(json_encode($animal), ENT_QUOTES, 'UTF-8'); ?>)">Editar</button>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="animal_id" value="<?php echo $animal['id']; ?>">
                                    <button type="submit" name="delete_animal">Eliminar</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Botón para abrir formulario -->
        <button class="add-animal-button" onclick="showAddForm()">Agregar Animal</button>

        <!-- Formulario emergente para agregar un animal -->
        <div id="add-form-container" class="form-container">
            <form method="POST" enctype="multipart/form-data">
                <label for="animal_nombre">Nombre del Animal:</label>
                <input type="text" name="animal_nombre" id="animal_nombre" required>

                <label for="nombre_cientifico">Nombre Científico:</label>
                <input type="text" name="nombre_cientifico" id="nombre_cientifico" required>

                <label for="longevidad">Longevidad:</label>
                <input type="text" name="longevidad" id="longevidad" required>

                <label for="crias">Crias:</label>
                <input type="text" name="crias" id="crias" required>

                <label for="dato_importante">Dato Importante:</label>
                <textarea name="dato_importante" id="dato_importante" required></textarea>

                <label for="orden_id">Orden:</label>
                <select name="orden_id" id="orden_id" required>
                    <option value="">Seleccionar Orden</option>
                    <?php foreach ($ordenes as $orden): ?>
                        <option value="<?php echo $orden['id']; ?>"><?php echo $orden['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="familia_id">Familia:</label>
                <select name="familia_id" id="familia_id" required>
                    <option value="">Seleccionar Familia</option>
                    <?php foreach ($familias as $familia): ?>
                        <option value="<?php echo $familia['id']; ?>"><?php echo $familia['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="especie_id">Especie:</label>
                <select name="especie_id" id="especie_id" required>
                    <option value="">Seleccionar Especie</option>
                    <?php foreach ($especies as $especie): ?>
                        <option value="<?php echo $especie['id']; ?>"><?php echo $especie['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="continente_id">Continente:</label>
                <select name="continente_id" id="continente_id" required>
                    <option value="">Seleccionar Continente</option>
                    <?php foreach ($continentes as $continente): ?>
                        <option value="<?php echo $continente['id']; ?>" <?php echo ($continente_id_seleccionado == $continente['id']) ? 'selected' : ''; ?>>
                            <?php echo $continente['nombre']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="imagen">Imagen (JPG/PNG):</label>
                <input type="file" name="imagen" id="imagen" accept=".jpg, .png" required>

                <button type="submit" name="add_animal">Agregar Animal</button>
                <button type="button" onclick="closeAddForm()">Cancelar</button>
            </form>
        </div>

        <!-- Formulario emergente para editar un animal -->
        <div id="form-container" class="form-container">
            <form method="POST" id="editForm">
                <input type="hidden" name="animal_id" id="edit_animal_id">
                <label for="animal_nombre">Nombre del Animal:</label>
                <input type="text" name="animal_nombre" id="edit_animal_nombre" required>
                <label for="nombre_cientifico">Nombre Científico:</label>
                <input type="text" name="nombre_cientifico" id="edit_nombre_cientifico" required>

                <label for="longevidad">Longevidad:</label>
                <input type="text" name="longevidad" id="edit_longevidad" required>

                <label for="crias">Crias:</label>
                <input type="text" name="crias" id="edit_crias" required>

                <label for="dato_importante">Dato Importante:</label>
                <textarea name="dato_importante" id="edit_dato_importante" required></textarea>

                <label for="orden_id">Orden:</label>
                <select name="orden_id" id="edit_orden_id" required>
                    <option value="">Seleccionar Orden</option>
                    <?php foreach ($ordenes as $orden): ?>
                        <option value="<?php echo $orden['id']; ?>"><?php echo $orden['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="familia_id">Familia:</label>
                <select name="familia_id" id="edit_familia_id" required>
                    <option value="">Seleccionar Familia</option>
                    <?php foreach ($familias as $familia): ?>
                        <option value="<?php echo $familia['id']; ?>"><?php echo $familia['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="especie_id">Especie:</label>
                <select name="especie_id" id="edit_especie_id" required>
                    <option value="">Seleccionar Especie</option>
                    <?php foreach ($especies as $especie): ?>
                        <option value="<?php echo $especie['id']; ?>"><?php echo $especie['nombre']; ?></option>
                    <?php endforeach; ?>
                </select>

                <button type="submit" name="edit_animal">Actualizar Animal</button>
                <button type="button" onclick="closeForm()">Cancelar</button>
            </form>
        </div>

        <!-- Alerta de éxito -->
        <?php if (isset($_GET['success'])): ?>
            <script>
                alert("Animal agregado con éxito");
            </script>
        <?php endif; ?>
        <?php if (isset($_GET['edited'])): ?>
            <script>
                alert("Se editó correctamente el animal");
            </script>
        <?php endif; ?>
        <?php if (isset($_GET['deleted'])): ?>
            <script>
                alert("Se eliminó correctamente");
            </script>
        <?php endif; ?>
    </main>

    <script>
        function showAnimals(id, continentName) {
            // Actualizar el título dinámico
            document.getElementById('dynamic-title').textContent = 'Animales de ' + continentName;

            // Redirigir a la misma página con el ID del continente
            window.location.href = "<?php echo $_SERVER['PHP_SELF']; ?>?continente_id=" + id;
        }

        function showAddForm() {
            document.getElementById('add-form-container').style.display = 'flex';
        }

        function closeAddForm() {
            document.getElementById('add-form-container').style.display = 'none';
        }

        function showForm(animal) {
            document.getElementById('edit_animal_id').value = animal.id;
            document.getElementById('edit_animal_nombre').value = animal.nombre;
            document.getElementById('edit_nombre_cientifico').value = animal.nombre_cientifico;
            document.getElementById('edit_longevidad').value = animal.longevidad;
            document.getElementById('edit_crias').value = animal.crias;
            document.getElementById('edit_dato_importante').value = animal.dato_importante;
            document.getElementById('edit_orden_id').value = animal.orden_id;
            document.getElementById('edit_familia_id').value = animal.familia_id;
            document.getElementById('edit_especie_id').value = animal.especie_id;

            document.getElementById('form-container').style.display = 'flex';
        }

        function closeForm() {
            document.getElementById('form-container').style.display = 'none';
        }
    </script>
</body>
</html>