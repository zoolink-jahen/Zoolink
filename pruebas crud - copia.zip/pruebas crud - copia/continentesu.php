<?php
// Conexion a la base de datos
$host = 'localhost';
$user = 'root';
$pass = ''; // Cambia con tu contraseña
$dbname = 'zoologico';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
    exit();
}

// Obtener todos los continentes
$continentesQuery = $pdo->query("SELECT * FROM continentes");
$continentes = $continentesQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las órdenes
$ordenesQuery = $pdo->query("SELECT * FROM orden");
$ordenes = $ordenesQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las familias
$familiasQuery = $pdo->query("SELECT * FROM familia");
$familias = $familiasQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener todas las especies
$especiesQuery = $pdo->query("SELECT * FROM especies");
$especies = $especiesQuery->fetchAll(PDO::FETCH_ASSOC);

// Obtener el continente_id de la URL si está presente
$continente_id_seleccionado = isset($_GET['continente_id']) ? $_GET['continente_id'] : null;

// Obtener animales según el continente seleccionado
$animalesQuery = $pdo->prepare("
    SELECT a.*, o.nombre AS orden_nombre, f.nombre AS familia_nombre, e.nombre AS especie_nombre 
    FROM animales a
    JOIN orden o ON a.orden_id = o.id
    JOIN familia f ON a.familia_id = f.id
    JOIN especies e ON a.especie_id = e.id
    WHERE a.continente_id = ?
");
$animalesQuery->execute([$continente_id_seleccionado]);
$animales = $animalesQuery->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Continentes y Animales</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* El estilo sigue igual */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f2e8;
            color: #333;
            line-height: 1.6;
        }

        main {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            color: #065f46;
            margin-bottom: 2rem;
        }

        .continente-buttons {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .continente-button {
            padding: 15px 30px; /* Aumentar tamaño de botones */
            background-color: #065f46;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 0 10px;
            transition: background-color 0.3s ease; /* Efecto interactivo */
        }

        .continente-button:hover {
            background-color: #05503a;
        }

        .animal-card {
            display: inline-block; /* Cambiado a inline-block para permitir alineación a la derecha */
            border: 1px solid #ddd;
            border-radius: 10px;
            margin: 10px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: calc(33.33% - 20px); /* 3 cartas por fila */
            transition: transform 0.2s; /* Efecto de transición */
            vertical-align: top; /* Alinear la parte superior de las cartas */
        }

        .animal-card:hover {
            transform: scale(1.05); /* Aumentar el tamaño al pasar el mouse */
        }

        .animal-card img {
            width: 100%; /* Ajusta la imagen al ancho de la carta */
            height: auto;
            max-height: 150px; /* Limitar la altura de la imagen */
            object-fit: cover; /* Mantener la proporción de la imagen */
        }

        .animal-card-content {
            padding: 15px;
        }

        .animal-card h3 {
            color: #065f46;
            margin-bottom: 10px;
        }

        /* Estilo para la información en negritas */
        .animal-card-content p strong {
            font-family: 'Arial', sans-serif; /* Cambiar tipo de letra */
            font-weight: bold; /* Mantener negrita */
        }

        /* Estilo para la información agregada */
        .animal-card-content p span {
            font-family: 'Courier New', monospace; /* Cambiar tipo de letra */
            font-weight: normal; /* Normalizar peso de la fuente */
        }

        /* Navbar */
        .navbar {
            background-color: #065f46;
            color: white;
            padding: 1rem 2rem;
        }

        .navbar ul {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0;
            margin: 0;
        }

        .navbar li {
            margin: 0 15px;
            list-style: none;
        }

        .navbar a {
            color: white;
            padding: 10px 15px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #05503a;
            border-radius: 5px;
        }

        /* Clearfix para el contenedor de cartas */
        .clearfix {
            display: flex;
            flex-wrap: wrap; /* Permitir que las cartas se envuelvan en filas */
            justify-content: flex-start; /* Alinear las cartas a la izquierda */
        }
    </style>
</head>
<body>
    <!-- Barra de navegación -->
    <nav class="navbar w-full p-4 shadow-md">
        <ul class="flex justify-center space-x-8">
            <li><a href="continentes.html" class="px-4 py-2 rounded">Continentes</a></li>
            <li><a href="historia.html" class="px-4 py-2 rounded">Historia</a></li>
            <li><a href="eventos1.html" class="px-4 py-2 rounded">Eventos</a></li>
            <li><a href="zonas.html" class="px-4 py-2 rounded">Zonas</a></li>
            <li><a href="inicioadmin.html" class="px-4 py-2 rounded">Inicio</a></li>
            <li><a href="ajustes.html" class="px-4 py-2 rounded">Ajustes</a></li>
            <li><a href="Index.html" class="px-4 py-2 bg-red-500 rounded hover:bg-red-600">Cerrar Sesión</a></li>
        </ul>
    </nav>

    <main>
        <h2>Continentes y sus Animales</h2>
        
        <!-- Botones de continentes -->
        <div class="continente-buttons">
            <?php foreach ($continentes as $continente): ?>
                <button class="continente-button" onclick="showAnimals('<?php echo $continente['id']; ?>', '<?php echo $continente['nombre']; ?>')">
                    <?php echo $continente['nombre']; ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Título dinámico -->
        <h3 id="dynamic-title" style="text-align: center; color: #065f46; margin-bottom: 20px;">
            <?php echo $continente_id_seleccionado ? 'Animales de ' . $continentes[array_search($continente_id_seleccionado, array_column($continentes, 'id'))]['nombre'] : ''; ?>
        </h3>

        <!-- Fichas de animales -->
        <div id="animal-cards" class="clearfix">
            <?php foreach ($animales as $animal): ?>
                <div class="animal-card">
                    <div class="animal-card-content">
                        <img src="<?php echo $animal['imagen']; ?>" alt="<?php echo $animal['nombre']; ?>">
                        <p><strong>Nombre:</strong> <span id="animal_name_<?php echo $animal['id']; ?>"><?php echo $animal['nombre']; ?></span></p>
                        <p><strong>Nombre Científico:</strong> <span><?php echo $animal['nombre_cientifico']; ?></span></p>
                        <p><strong>Longevidad:</strong> <span><?php echo $animal['longevidad']; ?></span></p>
                        <p><strong>Crias:</strong> <span><?php echo $animal['crias']; ?></span></p>
                        <p><strong>Dato Importante:</strong> <span><?php echo $animal['dato_importante']; ?></span></p>
                        <p><strong>Orden:</strong> <span><?php echo $animal['orden_nombre']; ?></span></p>
                        <p><strong>Familia:</strong> <span><?php echo $animal['familia_nombre']; ?></span></p>
                        <p><strong>Especie:</strong> <span><?php echo $animal['especie_nombre']; ?></span></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script>
        function showAnimals(id, continentName) {
            // Actualizar el título dinámico
            document.getElementById('dynamic-title').textContent = 'Animales de ' + continentName;

            // Redirigir a la misma página con el ID del continente
            window.location.href = "<?php echo $_SERVER['PHP_SELF']; ?>?continente_id=" + id;
        }
    </script>
</body>
</html>