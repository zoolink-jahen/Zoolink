CREATE TABLE especies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL UNIQUE
);

INSERT INTO especies (id, nombre) VALUES
    (1, 'Anfibios'),
    (2, 'Artrópodos'),
    (3, 'Aves'),
    (4, 'Mamíferos'),
    (5, 'Peces'),
    (6, 'Reptiles');

-- Tabla Continentes
CREATE TABLE Continentes (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Identificador único para cada continente
    nombre VARCHAR(100) NOT NULL        -- Nombre del continente (Ej. Asia, Europa, etc.)
);

-- Insertando los 5 continentes
INSERT INTO Continentes (nombre) 
VALUES
('Asia'),
('Europa'),
('África'),
('América'),
('Oceanía');

CREATE TABLE orden (
    id INT PRIMARY KEY,
    nombre VARCHAR(50)
);
INSERT INTO orden (id, nombre) VALUES
(1, 'Artiodactyla'),
(2, 'Carnivora'),
(3, 'Testudines'),
(4, 'Psittaciformes'),
(5, 'Siluriforme'),
(6, 'Primates'),
(7, 'Perciformes'),
(8, 'Characiforme'),
(9, 'Crocodylia'),
(10, 'Falconiformes'),
(11, 'Cetartiodactyla'),
(12, 'Strigiformes'),
(13, 'Struthionidae');


CREATE TABLE familia (
    id INT PRIMARY KEY,
    nombre VARCHAR(50)
);
INSERT INTO familia (id, nombre) VALUES
(1, 'Camelidae'),
(2, 'Procyonidae'),
(3, 'Emydidae'),
(4, 'Cacatuidae'),
(5, 'Pangasiidae'),
(6, 'Psittaculidae'),
(7, 'Cebidae'),
(8, 'Cichlidae'),
(9, 'Canidae'),
(10, 'Characidae'),
(11, 'Bovidae'),
(12, 'Cercopithecidae'),
(13, 'Ursidae'),
(14, 'Cervidae'),
(15, 'Crocodylidae'),
(16, 'Felidae'),
(17, 'Lemuridae'),
(18, 'Psittacidae'),
(19, 'Accipitridae'),
(20, 'Giraffidae'),
(21, 'Hippopotamidae'),
(22, 'Tytonidae'),
(23, 'Struthionidae');


CREATE TABLE animales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    nombre_cientifico VARCHAR(255) NOT NULL,
    longevidad INT,
    crias INT,
    dato_importante TEXT,
    orden_id INT,
    familia_id INT,
    especie_id INT,
    continente_id INT,
    imagen BLOB,
    FOREIGN KEY (orden_id) REFERENCES orden(id),
    FOREIGN KEY (familia_id) REFERENCES familia(id),
    FOREIGN KEY (especie_id) REFERENCES especies(id),
    FOREIGN KEY (continente_id) REFERENCES continentes(id)
);