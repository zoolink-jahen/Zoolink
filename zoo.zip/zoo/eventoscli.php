<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo_parque_del_pueblo";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Noticias y Eventos</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-green-50 font-sans">
    <!-- Barra de navegación -->
    <nav class="navbar" style="background-color: #065f46; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); padding: 1rem 0; position: sticky; top: 0; z-index: 1000;">
        <ul class="flex justify-center space-x-8">
            <li><a href="Index.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Inicio</a></li>
            <li><a href="#" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Mapa interactivo</a></li>
            <li><a href="informacion.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Información General</a></li>
            <li><a href="exhibiciones.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Exhibiciónes</a></li>
            <li><a href="experiencias.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Experiencias</a></li>
            <li><a href="eventoscli.php" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Noticias y Eventos</a></li>
        </ul>
    </nav>

    <main class="p-8">
        <h2 class="text-3xl font-bold text-center my-6 text-green-800">Noticias y Eventos</h2>
        
        <!-- Contenedor de los eventos -->
        <div id="eventos-container" class="cards-container grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php 
            // Consulta para obtener eventos y el nombre de la zona correspondiente
            $sql_eventos = "SELECT e.*, z.Nombre AS NombreZona 
                            FROM eventos e 
                            LEFT JOIN zonas z ON e.ZonaID = z.ZonaID";

            $result_eventos = $conn->query($sql_eventos);
            if ($result_eventos && $result_eventos->num_rows > 0) {
                while ($row = $result_eventos->fetch_assoc()) { ?>
                    <div class="card bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition-all">
                        <!-- Mostrar imagen del evento -->
                        <?php if (!empty($row['fotos'])) { ?>
                            <div class="overflow-hidden rounded-lg mb-4">
                                <img src="<?php echo $row['fotos']; ?>" alt="Imagen del evento" class="w-full h-48 object-cover rounded-lg shadow-md">
                            </div>
                        <?php } ?>
                        <h3 class="text-xl font-semibold text-green-700 mb-2"><?php echo htmlspecialchars($row['Nombre']); ?></h3>
                        <p class="text-gray-700 mb-2"><?php echo htmlspecialchars($row['Descripcion']); ?></p>
                        <p><strong>Fecha:</strong> <?php echo date('Y-m-d', strtotime($row['Fecha'])); ?></p>
                        <p><strong>Zona:</strong> <?php echo htmlspecialchars($row['NombreZona'] ?? 'Zona desconocida'); ?></p>
                    </div>
                <?php }
            } else { ?>
                <p class="text-gray-600">No hay eventos disponibles en este momento.</p>
            <?php } ?>
        </div>
    </main>
</body>
</html>

<?php $conn->close(); ?>
