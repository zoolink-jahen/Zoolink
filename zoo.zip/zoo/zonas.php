<?php
// Mostrar errores para desarrollo (desactiva en producción)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('conexion.php');

// Función para enviar respuesta JSON y salir
function sendResponse($response) {
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}

// Verificar si la tabla Zona existe
$result = $conn->query("SHOW TABLES LIKE 'Zona'");
if ($result->num_rows == 0) {
    sendResponse(['success' => false, 'error' => 'La tabla Zona no existe.']);
}

// Si la solicitud es GET, devolver la lista de zonas (sin imagen)
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $result = $conn->query("SELECT Id_Zona, Nombre, Descripcion, Coordenadas, Enlace, Tooltip FROM Zona");
    if (!$result) {
        sendResponse(['success' => false, 'error' => 'Error en la consulta: ' . $conn->error]);
    }
    $zones = [];
    while ($row = $result->fetch_assoc()) {
        $zones[] = $row;
    }
    sendResponse(['success' => true, 'zones' => $zones]);
}

// Si la solicitud es POST, se espera un parámetro "action"
elseif ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    if ($action == 'add') {
        // AGREGAR UNA NUEVA ZONA
        $nombre      = $_POST['nombre'];
        $coordenadas = $_POST['coordenadas'];
        $descripcion = $_POST['descripcion'];
        $tooltip     = $_POST['tooltip'];
        $enlace      = $_POST['enlace'];
    
        // Procesar imagen (si se envía)
        if (isset($_FILES['fotografia']) && $_FILES['fotografia']['error'] == 0) {
            $fileType = mime_content_type($_FILES['fotografia']['tmp_name']);
            if (strpos($fileType, 'image') === false) {
                sendResponse(['success' => false, 'error' => 'El archivo no es una imagen válida.']);
            }
            $fotografia = file_get_contents($_FILES['fotografia']['tmp_name']);
        } else {
            $fotografia = null;
        }
    
        $sql = "INSERT INTO Zona (Nombre, Descripcion, Coordenadas, Fotografia, Enlace, Tooltip) 
                VALUES (?, ?, ?, ?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param('ssssss', $nombre, $descripcion, $coordenadas, $fotografia, $enlace, $tooltip);
            if ($stmt->execute()) {
                sendResponse(['success' => true, 'message' => 'Zona agregada con éxito!']);
            } else {
                sendResponse(['success' => false, 'error' => 'Error al insertar los datos: ' . $stmt->error]);
            }
            $stmt->close();
        } else {
            sendResponse(['success' => false, 'error' => 'Error al preparar la consulta: ' . $conn->error]);
        }
    }
    elseif ($action == 'update') {
        // ACTUALIZAR UNA ZONA EXISTENTE
        $id          = $_POST['id'];
        $nombre      = $_POST['nombre'];
        $coordenadas = $_POST['coordenadas'];
        $descripcion = $_POST['descripcion'];
        $tooltip     = $_POST['tooltip'];
        $enlace      = $_POST['enlace'];
    
        // Si se envía una nueva imagen, actualizarla; de lo contrario, dejarla intacta.
        if (isset($_FILES['fotografia']) && $_FILES['fotografia']['error'] == 0) {
            $fileType = mime_content_type($_FILES['fotografia']['tmp_name']);
            if (strpos($fileType, 'image') === false) {
                sendResponse(['success' => false, 'error' => 'El archivo no es una imagen válida.']);
            }
            $fotografia = file_get_contents($_FILES['fotografia']['tmp_name']);
            $sql = "UPDATE Zona SET Nombre = ?, Descripcion = ?, Coordenadas = ?, Fotografia = ?, Enlace = ?, Tooltip = ? WHERE Id_Zona = ?";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param('ssssssi', $nombre, $descripcion, $coordenadas, $fotografia, $enlace, $tooltip, $id);
            } else {
                sendResponse(['success' => false, 'error' => 'Error al preparar la consulta: ' . $conn->error]);
            }
        } else {
            $sql = "UPDATE Zona SET Nombre = ?, Descripcion = ?, Coordenadas = ?, Enlace = ?, Tooltip = ? WHERE Id_Zona = ?";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param('sssssi', $nombre, $descripcion, $coordenadas, $enlace, $tooltip, $id);
            } else {
                sendResponse(['success' => false, 'error' => 'Error al preparar la consulta: ' . $conn->error]);
            }
        }
    
        if ($stmt->execute()) {
            sendResponse(['success' => true, 'message' => 'Zona actualizada con éxito!']);
        } else {
            sendResponse(['success' => false, 'error' => 'Error al actualizar los datos: ' . $stmt->error]);
        }
        $stmt->close();
    }
    elseif ($action == 'delete') {
        // ELIMINAR UNA ZONA
        $id = $_POST['id'];
        $sql = "DELETE FROM Zona WHERE Id_Zona = ?";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param('i', $id);
            if ($stmt->execute()) {
                sendResponse(['success' => true, 'message' => 'Zona eliminada con éxito!']);
            } else {
                sendResponse(['success' => false, 'error' => 'Error al eliminar la zona: ' . $stmt->error]);
            }
            $stmt->close();
        } else {
            sendResponse(['success' => false, 'error' => 'Error al preparar la consulta: ' . $conn->error]);
        }
    }
    else {
        sendResponse(['success' => false, 'error' => 'Acción no válida.']);
    }
}
$conn->close();
?>