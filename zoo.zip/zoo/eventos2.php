<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoo_parque_del_pueblo";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    // Agregar un nuevo evento
    if ($_POST['action'] == 'add') {
        $nombre = $_POST["name"];
        $descripcion = $_POST["description"];
        $fecha = $_POST["date"];
        $zona_id = $_POST["zoneId"];
        $fotos = $_POST["fotos"];

        $sql = "INSERT INTO eventos (Nombre, Descripcion, Fecha, ZonaID, fotos) VALUES ('$nombre', '$descripcion', '$fecha', '$zona_id', '$fotos')";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Evento agregado correctamente'); window.location.reload();</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Editar un evento
    if ($_POST['action'] == 'edit') {
        $evento_id = $_POST['evento_id'];
        $nombre = $_POST["name"];
        $descripcion = $_POST["description"];
        $fecha = $_POST["date"];
        $zona_id = $_POST["zoneId"];
        $fotos = $_POST["fotos"];

        $sql = "UPDATE eventos SET Nombre='$nombre', Descripcion='$descripcion', Fecha='$fecha', ZonaID='$zona_id', fotos='$fotos' WHERE EventoID=$evento_id";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Evento actualizado correctamente'); window.location.href='eventos2.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    // Eliminar un evento
    if ($_POST['action'] == 'delete') {
        $evento_id = $_POST['evento_id'];
        $sql = "DELETE FROM eventos WHERE EventoID=$evento_id";
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Evento eliminado correctamente'); window.location.href='eventos2.php';</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

// Si se está editando un evento, cargar los datos del evento
if (isset($_GET['evento_id'])) {
    $evento_id = $_GET['evento_id'];
    $sql_evento = "SELECT * FROM eventos WHERE EventoID = $evento_id";
    $result_evento = $conn->query($sql_evento);
    $evento = $result_evento->fetch_assoc();
}

$sql_zonas = "SELECT * FROM zonas";
$result_zonas = $conn->query($sql_zonas);
$sql_eventos = "SELECT eventos.*, zonas.Nombre as NombreZona FROM eventos JOIN zonas ON eventos.ZonaID = zonas.ZonaID";
$result_eventos = $conn->query($sql_eventos);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Noticias y Eventos</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function confirmarEliminacion(event) {
            if (!confirm("¿Estás seguro de que deseas eliminar este evento?")) {
                event.preventDefault();
            }
        }
    </script>
</head>
<body class="bg-gray-100">
<nav class="navbar" style="background-color: #065f46; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); padding: 1rem 0; position: sticky; top: 0; z-index: 1000;">
    <ul class="flex justify-center space-x-8">
        <li><a href="continentes.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Continentes</a></li>
        <li><a href="historia.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Historia</a></li>
        <li><a href="eventos2.php" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Eventos</a></li>
        <li><a href="zonas.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Zonas</a></li>
        <li><a href="inicioadmin.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Inicio</a></li>
        <li><a href="ajustes.html" class="px-4 py-2 text-white rounded hover:bg-[#047857]">Ajustes</a></li>
        <li><a href="Index.html" class="px-4 py-2 bg-red-500 rounded hover:bg-red-600">Cerrar Sesión</a></li>
    </ul>
</nav>

<main class="p-8">
    <h2 class="text-3xl mb-6 text-center font-semibold">Noticias y Eventos</h2>

    <!-- Formulario para agregar o editar evento -->
    <div class="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <form method="POST">
            <input type="text" name="name" placeholder="Nombre del evento" class="w-full p-2 mb-4 border border-gray-300 rounded" required value="<?php echo isset($evento) ? $evento['Nombre'] : ''; ?>" />
            <textarea name="description" rows="4" placeholder="Descripción del evento" class="w-full p-2 mb-4 border border-gray-300 rounded" required><?php echo isset($evento) ? $evento['Descripcion'] : ''; ?></textarea>
            <input type="date" name="date" class="w-full p-2 mb-4 border border-gray-300 rounded" required value="<?php echo isset($evento) ? $evento['Fecha'] : ''; ?>" />
            <select name="zoneId" class="w-full p-2 mb-4 border border-gray-300 rounded" required>
                <?php while ($row = $result_zonas->fetch_assoc()) { ?>
                    <option value="<?php echo $row['ZonaID']; ?>" <?php echo isset($evento) && $evento['ZonaID'] == $row['ZonaID'] ? 'selected' : ''; ?>><?php echo $row['Nombre']; ?></option>
                <?php } ?>
            </select>
            <input type="text" name="fotos" placeholder="URL de la foto" class="w-full p-2 mb-4 border border-gray-300 rounded" value="<?php echo isset($evento) ? $evento['fotos'] : ''; ?>" />
            
            <input type="hidden" name="evento_id" value="<?php echo isset($evento) ? $evento['EventoID'] : ''; ?>">
            
            <button type="submit" name="action" value="<?php echo isset($evento) ? 'edit' : 'add'; ?>" class="w-full py-2 bg-green-600 text-white rounded">
                <?php echo isset($evento) ? 'Editar Evento' : 'Agregar Evento'; ?>
            </button>
        </form>
    </div>

    <!-- Mostrar los eventos -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        <?php while ($row = $result_eventos->fetch_assoc()) { ?>
            <div class="card bg-white p-4 rounded-lg shadow-md">
                <h3 class="text-xl font-semibold mb-2"><?php echo $row['Nombre']; ?></h3>
                <p class="text-gray-600 mb-2"><?php echo $row['Descripcion']; ?></p>
                <p><strong>Fecha:</strong> <?php echo date('Y-m-d', strtotime($row['Fecha'])); ?></p>
                <p><strong>Zona:</strong> <?php echo $row['NombreZona']; ?></p>

                <?php if ($row['fotos']) { ?>
                    <div class="mt-4">
                        <img src="<?php echo $row['fotos']; ?>" alt="Imagen del evento" class="w-full h-64 object-cover rounded-lg">
                    </div>
                <?php } ?>

                <!-- Botones para editar y eliminar -->
                <div class="mt-4 flex justify-between">
                    <form method="GET" action="" class="w-1/2 mr-2">
                        <input type="hidden" name="evento_id" value="<?php echo $row['EventoID']; ?>">
                        <button type="submit" class="w-full py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">Editar</button>
                    </form>

                    <form method="POST" class="w-1/2 ml-2" onsubmit="confirmarEliminacion(event)">
                        <input type="hidden" name="evento_id" value="<?php echo $row['EventoID']; ?>">
                        <button type="submit" name="action" value="delete" class="w-full py-2 bg-red-600 text-white rounded hover:bg-red-700">Eliminar</button>
                    </form>
                </div>
            </div>
        <?php } ?>
    </div>
</main>
</body>
</html>

<?php $conn->close(); ?>
