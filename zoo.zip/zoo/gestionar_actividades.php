<?php
include 'conexion.php';

// Procesar eliminación de actividad
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    $sql = "DELETE FROM actividades WHERE id = $id";
    $conn->query($sql);
    header("Location: gestionar_actividades.php");
}

// Procesar formulario de agregar o editar actividad
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? '';
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $fecha = $_POST['fecha'];
    $horario = $_POST['horario'];
    $lugar = $_POST['lugar'];

    // Manejo de la imagen
    if (!empty($_FILES['imagen']['name'])) {
        $imagen = $_FILES['imagen']['name'];
        $ruta = "imagenes/" . basename($imagen);
        move_uploaded_file($_FILES['imagen']['tmp_name'], $ruta);
    } else {
        $ruta = $_POST['imagen_actual'] ?? '';
    }

    if (!empty($id)) {
        // Editar actividad
        $sql = "UPDATE actividades SET 
                nombre='$nombre', 
                descripcion='$descripcion', 
                fecha='$fecha', 
                horario='$horario', 
                imagen='$ruta', 
                lugar='$lugar' 
                WHERE id=$id";
    } else {
        // Insertar nueva actividad
        $sql = "INSERT INTO actividades (nombre, descripcion, fecha, horario, imagen, lugar) 
                VALUES ('$nombre', '$descripcion', '$fecha', '$horario', '$ruta', '$lugar')";
    }

    $conn->query($sql);
    header("Location: gestionar_actividades.php");
}

// Obtener actividades para mostrar en cards
$result = $conn->query("SELECT * FROM actividades");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Actividades</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }

        .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .card {
            width: 300px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: all 0.3s ease-in-out;
            border: 3px solid transparent;
        }

        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            border-color: #4CAF50;
            transform: scale(1.05);
        }

        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }

        .card h3 {
            color: #065f46;
            margin: 10px 0;
        }

        .card p {
            padding: 0 10px;
            font-size: 14px;
            color: #555;
        }

        .card a, .btn-edit {
            display: block;
            margin: 10px auto;
            padding: 8px 12px;
            text-align: center;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            width: 80%;
        }

        .btn-edit {
            background-color: #facc15;
            color: black;
        }

        .btn-delete {
            background-color: #ef4444;
            color: white;
        }

        form {
            max-width: 500px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 3px solid transparent;
            transition: all 0.3s ease-in-out;
        }

        form:hover {
            border-color: #4CAF50;
            transform: scale(1.02);
        }

        input, textarea, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #065f46;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #047857;
        }

        /* Formulario emergente */
        .edit-form {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            z-index: 1000;
        }

        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }

        .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .card {
            width: 300px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: all 0.3s ease-in-out;
            border: 3px solid transparent;
        }

        .card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            border-color: #4CAF50; /* Verde iluminado */
            transform: scale(1.05);
        }

        .card img {
            width: 100%;
            height: 180px;
            object-fit: cover;
        }

        .card h3 {
            color: #065f46;
            margin: 10px 0;
        }

        .card p {
            padding: 0 10px;
            font-size: 14px;
            color: #555;
        }

        .card a {
            display: block;
            margin: 10px auto;
            padding: 8px 12px;
            background-color: #ef4444;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            width: 80%;
            text-align: center;
            transition: background 0.3s;
        }

        .card a:hover {
            background-color: #dc2626;
        }

        form {
            max-width: 500px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: 3px solid transparent;
            transition: all 0.3s ease-in-out;
        }

        form:hover {
            border-color: #4CAF50;
            transform: scale(1.02);
        }

        input, textarea, button {
            width: 100%;
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            background-color: #065f46;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #047857;
        }

        nav {
            background-color: #065f46;
            color: white;
            padding: 1rem 0;
            display: flex;
            justify-content: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        nav ul {
            display: flex;
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav li {
            margin: 0 15px;
        }

        nav a {
            text-decoration: none;
            color: white;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }

        nav a:hover {
            background-color: #047857;
        }

        nav .bg-red-500 {
            background-color: #ef4444;
        }

        nav .bg-red-500:hover {
            background-color: #dc2626;
        }
    </style>
</head>
<body>
<nav class="navbar w-full p-4 shadow-md">
    <ul class="flex justify-center space-x-8">
        <li><a href="continentes.html">Continentes</a></li>
        <li><a href="historia.html">Historia</a></li>
        <li><a href="eventos2.php">Eventos</a></li>
        <li><a href="zonas.html">Zonas</a></li>
        <li><a href="gestionar_actividades.php">Actividades</a></li> <!-- Nueva pestaña -->
        <li><a href="inicioadmin.html">Inicio</a></li>
        <li><a href="ajustes.html">Ajustes</a></li>
        <li><a href="Index.html" class="bg-red-500">Cerrar Sesión</a></li>
    </ul>
</nav>

<h1>Gestionar Actividades</h1>

<form action="gestionar_actividades.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" id="id">
    <input type="text" name="nombre" placeholder="Nombre de la actividad" required>
    <textarea name="descripcion" placeholder="Breve descripción" required></textarea>
    <input type="date" name="fecha" required>
    <input type="time" name="horario" required>
    <input type="file" name="imagen" required>
    <input type="text" name="lugar" placeholder="Lugar de la actividad" required>
    <button type="submit">Guardar Actividad</button>
</form>

<h2>Actividades Registradas</h2>
<div class="cards-container">
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="card">
            <img src="<?php echo $row['imagen']; ?>" alt="Imagen de la actividad">
            <h3><?php echo $row['nombre']; ?></h3>
            <p><?php echo $row['descripcion']; ?></p>
            <p><strong>Fecha:</strong> <?php echo $row['fecha']; ?></p>
            <p><strong>Horario:</strong> <?php echo $row['horario']; ?></p>
            <p><strong>Lugar:</strong> <?php echo $row['lugar']; ?></p>
            <button class="btn-edit" onclick="openEditForm(
                '<?php echo $row['id']; ?>', 
                '<?php echo $row['nombre']; ?>', 
                '<?php echo $row['descripcion']; ?>', 
                '<?php echo $row['fecha']; ?>', 
                '<?php echo $row['horario']; ?>', 
                '<?php echo $row['lugar']; ?>', 
                '<?php echo $row['imagen']; ?>'
            )">Editar</button>
            <a href="gestionar_actividades.php?eliminar=<?php echo $row['id']; ?>" class="btn-delete" onclick="return confirm('¿Estás seguro de eliminar esta actividad?');">Eliminar</a>
        </div>
    <?php endwhile; ?>
</div>

<!-- Formulario para editar actividad -->
<div class="overlay" id="overlay"></div>
<div class="edit-form" id="edit-form">
    <h2>Editar Actividad</h2>
    <form action="gestionar_actividades.php" method="POST" enctype="multipart/form-data">
        <input type="hidden" id="edit-id" name="id">
        <input type="text" id="edit-nombre" name="nombre" required>
        <textarea id="edit-descripcion" name="descripcion" required></textarea>
        <input type="date" id="edit-fecha" name="fecha" required>
        <input type="text" id="edit-horario" name="horario" required>
        <input type="text" id="edit-lugar" name="lugar" required>
        <input type="file" name="imagen">
        <input type="hidden" id="edit-imagen-actual" name="imagen_actual">
        <button type="submit">Guardar Cambios</button>
    </form>
    <button onclick="closeEditForm()">Cancelar</button>
</div>

<script>
    function openEditForm(id, nombre, descripcion, fecha, horario, lugar, imagen) {
        document.getElementById('edit-id').value = id;
        document.getElementById('edit-nombre').value = nombre;
        document.getElementById('edit-descripcion').value = descripcion;
        document.getElementById('edit-fecha').value = fecha;
        document.getElementById('edit-horario').value = horario;
        document.getElementById('edit-lugar').value = lugar;
        document.getElementById('edit-imagen-actual').value = imagen;

        document.getElementById('overlay').style.display = 'block';
        document.getElementById('edit-form').style.display = 'block';
    }

    function closeEditForm() {
        document.getElementById('overlay').style.display = 'none';
        document.getElementById('edit-form').style.display = 'none';
    }
</script>

</body>
</html>
